const log = async ({ logName, logValue }) => {
	console.log(`${logName}` + item);

	return {
		result: '',
	};
};

export default log;
