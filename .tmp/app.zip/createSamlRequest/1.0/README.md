# createSamlRequest

The createSamlRequest function can be used to initiate a SAML SSO flow. It takes arguments for the idpSsoTargetUrl, issuer, callback url and nameIdentifierFormat
