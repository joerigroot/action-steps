# redirect

Generates a Response object that can be used as the action output to redirect the browser to the given url after executing the Action via a POST / GET / PUT request.
