# processSamlResponse

Processes a SAMLResponse object and returns the nameID, givenName of the user and the surname of the user if present

# Usage

Make sure to install Base64 and xml-js packages before publishing!
