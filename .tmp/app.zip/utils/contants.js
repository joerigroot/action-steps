/* eslint-disable import/prefer-default-export */
export const RelationKind = {
	HAS_AND_BELONGS_TO_MANY: 'HAS_AND_BELONGS_TO_MANY',
	BELONGS_TO: 'BELONGS_TO',
	HAS_MANY: 'HAS_MANY',
};
