# stringifyJwtToken

Converts a jwtToken object to a proper string that can be used in the redirect step or concatString step, otherwise the string will be [object Object]
